import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: []
})
export class NavbarComponent implements OnInit {

  constructor(private router: Router, public service: UserService) { }
  Notifications;
  //public totalCount: number = this.Notifications.length;
public totalCount: number ;
  public name: string;
  public img: string;
  ngOnInit() {
    this.service.getUserNotifications().subscribe(
      (res: any) => {
        this.Notifications = res;
        if (this.Notifications.length>0)
        this.totalCount = this.Notifications.length;
      },
      err => {
        console.log(err);
      },
    );
    this.service.getUserProfile().subscribe( 
      (res: any) => {
        this.name = res.fullName;
        if(res.imageUrl!=null)
          this.img =  res.imageUrl;
        else
          this.img ="assets/img/0.png"
      },
      err => {
        console.log(err);
      }
    );
  }

  onLogout() {
    localStorage.removeItem('token');
    this.router.navigate(['user/login']);
  }
}
