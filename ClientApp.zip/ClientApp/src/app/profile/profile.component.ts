import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { UserService } from '../shared/user.service';
import { HttpEventType, HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: []
})
export class ProfileComponent implements OnInit {
  public progress: number;
  public message: string;
  public img: string;
 
  Members;

  constructor(public service: UserService, private router: Router) { }
  formModel = {
    Name: '',
    Email: '',
    CarNumber: '',
  }

  memberModel = {
    Name: '',
    Gender: 'Male',
    Relation:''
  }
  ngOnInit() {
    this.memberModel.Name= '';
    this.memberModel.Gender= 'Male';
    this.memberModel.Relation= '';
    this.service.getUserProfile().subscribe(
      (res: any) => {
        this.formModel.Name = res.fullName;
        this.formModel.Email = res.email;
        this.formModel.CarNumber = res.userName;
        if (res.imageUrl != null)
          this.img =  res.imageUrl;
        else
          this.img = "assets/img/0.png"
      },
      err => {
        console.log(err);
      }
    );

    this.service.getMembers().subscribe(
      (res: any) => {
        this.Members = res;
      },
      err => {
        console.log(err);
      }
    );
  }

  onSubmit(form: NgForm) {
    this.service.addMember(form.value).subscribe(
      (res: any) => {
        this.ngOnInit();
      },
      err => {
        console.log(err);
      }
    );
  }

  public uploadFile = (files) => {
    if (files.length === 0) {
      return;
    }

    let fileToUpload = <File>files[0];
    const formData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
    this.service.uploadImage(formData)
      .subscribe(
        res => {
          this.router.navigateByUrl('/home/profile');
          console.log(res);
        },
        err => {
          this.router.navigateByUrl('/home/profile');
          console.log(err);
        },
    );
  }
}
