import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './../../shared/user.service';
import { NgForm } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: []
})
export class LoginComponent implements OnInit {
  formModel = {
    UserName: '',
    Password: ''
  }
  constructor(private service: UserService, private router: Router, private spinner: NgxSpinnerService, private toastr: ToastrService) { }

  ngOnInit(): void {
    if (localStorage.getItem('token') != null)
      this.router.navigateByUrl('/home');
  }


  onSubmit(form: NgForm) {
    this.spinner.show();
    this.service.login(form.value).subscribe(
      (res: any) => {
        this.spinner.hide();
        localStorage.setItem('token', res.token);
        if (this.service.roleMatch(['Admin']))
          this.router.navigateByUrl('/home/requests');
        else
          this.router.navigateByUrl('/home/myrequests');
      },
      err => {
        this.spinner.hide();
        if (err.status === 400)
          this.toastr.error('Incorrect username or password.', 'Authentication failed.');
        else
          console.log(err);
      }
    );
  }
}
