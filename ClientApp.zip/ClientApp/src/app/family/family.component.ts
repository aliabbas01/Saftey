import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-family',
  templateUrl: './family.component.html',
  styleUrls: []
})
export class FamilyComponent implements OnInit {
  Members;
  constructor(private route: ActivatedRoute, public service: UserService) { }

  ngOnInit() {
    const userId: string = this.route.snapshot.queryParamMap.get('id');
    this.service.getFamily(userId).subscribe(
      (res: any) => {
        this.Members = res;
      },
      err => {
        console.log(err);
      }
    );
  }

}
