import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-myrequests',
  templateUrl: './myrequests.component.html',
  styleUrls: []
})
export class MyrequestsComponent implements OnInit {

  constructor(private service: UserService) { }
  Requests;
  ngOnInit() {
    
  this.service.getUserRequests().subscribe(
    res => {
      this.Requests = res;
    },
    err => {
      console.log(err);
    },
  );
}
  }
