import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: []
})
export class RequestsComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }
  Requests;
  ngOnInit() {
      this.service.getRequests().subscribe(
        res => {
          this.Requests = res;
        },
        err => {
          console.log(err);
        },
      );
  }

  editRequest(id) {
  this.router.navigateByUrl('home/editrequest?id=' + id);
}
  }


