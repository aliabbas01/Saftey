import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: []
})
export class UsersComponent implements OnInit {

  constructor(private service: UserService, private router: Router) { }
  Users;
  ngOnInit() {
    this.service.getUsers().subscribe(
      res => {
        this.Users = res;
      },
      err => {
        console.log(err);
      },
    );
  }


  viewFamily(id) {
    this.router.navigateByUrl('home/family?id=' + id);
  }
}
