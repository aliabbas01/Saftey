import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { HomeComponent } from './home/home.component';
import { NewrequestComponent } from './newrequest/newrequest.component';
import { ProfileComponent } from './profile/profile.component';
import { RequestsComponent } from './requests/requests.component';
import { UsersComponent } from './users/users.component';
import { MyrequestsComponent } from './myrequests/myrequests.component';
import { EditrequestComponent } from './editrequest/editrequest.component';
import { AuthGuard } from './auth/auth.guard';
import { FamilyComponent } from './family/family.component';


const routes: Routes = [
  { path: '', redirectTo: '/user/login', pathMatch: 'full' },
  {
    path: 'user', component: UserComponent,
    children: [
      { path: 'registration', component: RegistrationComponent },
      { path: 'login', component: LoginComponent }
    ]
  },
  {
    path: 'home', component: HomeComponent,
    children: [
      { path: 'profile', component: ProfileComponent },
      { path: 'newrequest', component: NewrequestComponent },
      { path: 'requests', component: RequestsComponent, canActivate: [AuthGuard], data: { permittedRoles: ['Admin'] } },
      { path: 'users', component: UsersComponent, canActivate: [AuthGuard], data: { permittedRoles: ['Admin'] } },
      { path: 'family', component: FamilyComponent, canActivate: [AuthGuard], data: { permittedRoles: ['Admin'] } },
      { path: 'myrequests', component: MyrequestsComponent },
      { path: 'editrequest', component: EditrequestComponent, canActivate: [AuthGuard], data: { permittedRoles: ['Admin'] } }
      
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
