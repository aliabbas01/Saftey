import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../shared/user.service';
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from '@angular/router';

@Component({
  selector: 'app-newrequest',
  templateUrl: './newrequest.component.html',
  styleUrls: []
})
export class NewrequestComponent implements OnInit {
  formModel = {
    CurrentCity: '',
    DestinationCity: '',
    CovidAffected: 'NO',
    KnowCovid: 'NO',
    Family:'NO',
    CreatedBy: this.getUserId()
  }
  constructor(private service: UserService, private router: Router, private spinner: NgxSpinnerService) { }
  Request;
  ngOnInit(): void {
    this.service.getNewRequest().subscribe(
      res => {
        this.Request = res;
      },
      err => {
        console.log(err);
      },
    );
  }

  getUserId() {
    const token = localStorage.getItem("token");
    let payload;
    if (token) {
      payload = token.split(".")[1];
      payload = window.atob(payload);
      payload = JSON.parse(payload);
      return payload.UserID;
    } else {
      return null;
    }
  }
  onSubmit(form: NgForm) {
    this.spinner.show();
    this.service.addRequest(form.value).subscribe(
      (res: any) => {
        this.spinner.hide();
        this.router.navigateByUrl('/home/myrequests');
      },
      err => {
        this.spinner.hide();
          console.log(err);
      }
    );
  }
}


