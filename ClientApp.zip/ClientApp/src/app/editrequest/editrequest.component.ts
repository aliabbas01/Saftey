import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../shared/user.service';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-editrequest',
  templateUrl: './editrequest.component.html',
  styleUrls: []
})
export class EditrequestComponent implements OnInit {

  constructor(private route: ActivatedRoute, public service: UserService, private router: Router) { }
  formModel = {
    RequestId:'',
    CurrentCity: '',
    DestinationCity: '',
    CovidAffected: 'NO',
    KnowCovid: 'NO',
    Family:'NO',
    Status: '',
    Message:''
  }
  ngOnInit() {
    const requestid: string = this.route.snapshot.queryParamMap.get('id');
    this.service.getRequest(requestid).subscribe(
      (res: any) => {
        this.formModel.RequestId = res.requestId;
        this.formModel.CurrentCity = res.currentCity;
        this.formModel.DestinationCity = res.destinationCity;
        this.formModel.CovidAffected = res.covidAffected;
        this.formModel.KnowCovid = res.knowCovid;
        this.formModel.Family = res.family;
        this.formModel.Status = res.status;
        this.formModel.Message=res.message
      },
      err => {
        console.log(err);
      }
    );
  }

  onSubmit(form: NgForm) {
    this.service.updateRequest(form.value).subscribe(
      (res: any) => {
        this.router.navigateByUrl('/home/requests');
      },
      err => {
        console.log(err);
      }
    );
  }

}
